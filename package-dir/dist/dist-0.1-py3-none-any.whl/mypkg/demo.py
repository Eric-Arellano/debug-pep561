def foo(x: str) -> None:
    pass

